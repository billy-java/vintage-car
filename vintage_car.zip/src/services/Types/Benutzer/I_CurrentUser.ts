interface I_CurrentUser {
  aktuell_U: string;
  be_L: string;
  be_S: string;
  be_A: string;
  be_T: string;
  id_lagers: string[];
  id_beantragte_Lagers: string[];
  id_services: string[];
  id_beantragte_Services: string[]
  id_autos: string[];
  id_termine: string[];
}

export default I_CurrentUser;
