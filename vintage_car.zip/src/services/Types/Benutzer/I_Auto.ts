interface I_Auto {
  id: string;
  id_Benutzer: string;
  id_Lagerplatz: string;
  name: string;
  marke: string;
  farbe: string;
}

export default I_Auto;
