interface I_Lagerplatzreservierung {
  id: string;
  id_Benutzer: string;
  id_Lagerplatz: string;
  id_Auto: string;
  stand: string;
}

export default I_Lagerplatzreservierung;
