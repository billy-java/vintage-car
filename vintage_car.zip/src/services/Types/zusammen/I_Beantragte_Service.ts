interface I_Beantragte_Service {
  id: string;
  id_Benutzer: string;
  id_Lagerplatz: string;
  id_Service: string;
  id_Auto: string;
  stand: string; //stand
}

export default I_Beantragte_Service;
