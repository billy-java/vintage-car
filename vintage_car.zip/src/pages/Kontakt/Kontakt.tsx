import React from 'react';
import './Kontakt.css';

const Kontakt = () => {
  return (
    <div className="container">
      <main>
        <section className="contact-section">
          <h2 className="text-3xl font-extrabold">Projektmanager</h2>
          <div>
            <p>
              <strong>Nom :</strong> Ezechiel Djidefehe
            </p>
            <p>
              <strong>Email :</strong>
              <a href="mailto:ezechiel.djidefehe.tiaghoue@mni.thm.de">
              ezechiel.djidefehe.tiaghoue@mni.thm.de
              </a>
            </p>
          </div>
        </section>
        <section className="contact-section">
          <h2 className="text-3xl font-extrabold">
            Lead Requirements Engineer
          </h2>
          <div>
            <p>
              <strong>Nom :</strong> Lanvin Njinpie Noutche
            </p>
            <p>
              <strong>Email :</strong>
              <a href="mailto:Clyde.lanvin.njinpie.noutche@mni.thm.de">
              Clyde.lanvin.njinpie.noutche@mni.thm.de
              </a>
            </p>
          </div>
        </section>
        <section className="contact-section">
          <h2 className="text-3xl font-extrabold">Lead Software-Architekt</h2>
          <div>
            <p>
              <strong>Nom :</strong> Billy Babou
            </p>
            <p>
              <strong>Email :</strong>
              <a href="mailto:babou.billy.meudji@mni.thm.de">
              babou.billy.meudji@mni.thm.de
              </a>
            </p>
          </div>
        </section>
      </main>
      <footer>
        <p>&copy; 2024 Vintage Car</p>
      </footer>
    </div>
  );
};

export default Kontakt;
